﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Spawnerscript : MonoBehaviour
{
    public GameObject[] Cubes;
    float PositionY;

    private int Score = 0;
    public Text TXTScore;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnObjects", 1, 1);
    }
    void SpawnObjects()
    {
        PositionY = Random.Range(4, -4f);
        transform.position = new Vector3(transform.position.x, PositionY, transform.position.z);
        Instantiate(Cubes[Random.Range(0, Cubes.Length)], transform.position, transform.rotation);
    }
    
}
