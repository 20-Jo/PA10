﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TriggerScript : MonoBehaviour
{
    private int Score = 0;
    public Text TXTScore;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Obstacle"))
        {
            Score++;
            TXTScore.text = "Score: " + Score;
        }
    }
}
